import { timezones } from '../../../../../lib/locale/timezones.js';

export default {
  Query: {
    timezones: () => timezones
  }
};
